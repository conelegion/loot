<?php
class indexController extends Controller {
	function index_action() {
		$this->View('index');
	}
}