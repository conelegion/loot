<?php
define('APP', dirname(__FILE__)."/../app/");
define('CONTROLLERS', APP."controllers/");
define('MODELS', APP."models/");
define('VIEWS', APP."views/");
define('PUBLIC_HTML', dirname(__FILE__)."/../public/");