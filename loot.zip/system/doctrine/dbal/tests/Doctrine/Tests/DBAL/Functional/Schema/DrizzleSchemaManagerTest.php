<?php

namespace Doctrine\Tests\DBAL\Functional\Schema;

use Doctrine\DBAL\Schema\Table;
use Doctrine\DBAL\Schema\Schema;

require_once __DIR__ . '/../../../TestInit.php';

class DrizzleSchemaManagerTest extends SchemaManagerFunctionalTestCase
{
}