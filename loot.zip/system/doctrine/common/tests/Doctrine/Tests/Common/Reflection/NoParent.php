<?php

namespace Doctrine\Tests\Common\Reflection;

class NoParent
{
    public $test;
}
