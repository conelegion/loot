<?php
session_start();
$start = require_once('system/start.php');

$start->run();